class url
{
baseurl(url)
{
cy.visit("https://service.damastage.com/#/dplogin")
}
}
export default url;