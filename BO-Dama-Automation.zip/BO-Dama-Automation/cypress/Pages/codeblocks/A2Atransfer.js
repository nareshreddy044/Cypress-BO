import A2ATransfer from "../Transactions/A2A";
class A2Atransferclass
{
static A2Atransfermethod()
{   
    const A2A = new A2ATransfer;
    A2A.transactionprocessingbutton()
    A2A.A2Atransferbutton()
    A2A.initiateA2A()
    A2A.A2Aclientnameenter()
    A2A.A2Aclientnameselect()
    A2A.A2Afromaccount()
    A2A.A2Afromaccountselect()
    A2A.A2Atoaccount()
    A2A.A2Atoaccountselect()
    A2A.A2Aamount()
    A2A.A2Aremarks()
    A2A.A2Ainternalremarks()
    A2A.A2Asubmit()
}
static A2Atransferapprovemethod()
{   
    const A2A = new A2ATransfer;
      A2A.transactionprocessingbutton()
      A2A.A2Atransferbutton()
      A2A.A2Asearchbutton()
      A2A.A2Astatustab()
      A2A.A2Astatusselecttab()
      A2A.A2Afromaccountsearchtab()
      A2A.A2Atoaccountsearchtab()
      A2A.A2Asearchsubmitbutton()
      A2A.A2Aapprovebutton()
}
static A2Aexportmethod()
{
      const A2A = new A2ATransfer;
      A2A.transactionprocessingbutton()
      A2A.A2Atransferbutton()
      A2A.A2Aexport()
}
}
export default A2Atransferclass;