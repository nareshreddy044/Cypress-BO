import adjustment from "../Transactions/Adjustment";
class adjustmentclass
{
    static adjustmentmethod()
    {
      const adj = new adjustment;
      adj.transactionprocessingbutton()
      adj.adjustmentselect()
      adj.addadjustment()
      adj.adjustmentclienttype()
      adj.adjustmentbusinessclient()
      adj.adjustmentclient()
      adj.adjustmentclientselect()
      adj.adjustmentaccountnumber()
      adj.adjustmentaccountnumberselect()
      adj.adjustmentamount()
      adj.adjustmenttype()
      adj.adjustmenttypeselect()
      adj.adjustmenttransactionalremarks()
      adj.adjustmenttransactionalremarksselect()
      adj.adjustmentremarks()
      adj.adjustmentinternalremarks()
      adj.adjustmentsubmit()
      adj.adjustmentiframe()
    }
}
export default adjustmentclass;