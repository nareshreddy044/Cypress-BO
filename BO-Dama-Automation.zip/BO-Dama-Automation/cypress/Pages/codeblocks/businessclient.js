import businessclient from "../Businessclientpage";
class businessclientclass{
static businessclientsearch()
{
const bcs= new businessclient;
  bcs.clientbutton()
  bcs.businessclientbutton()
  bcs.clientsearch()
  bcs.clientnametype()
  bcs.clientselect()
  bcs.clientsearchsubmit()
  bcs.clientnamelink()
  bcs.clientnamecheck
}
}
export default businessclientclass;