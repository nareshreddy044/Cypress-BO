class adjustment
{
    transactionprocessingbutton(transactionprocessingbutton)
    {
        cy.xpath("//a[contains(.,'Transaction Processing')]").click()
    }
    adjustmentselect(adjustmentselect)
    {
        cy.xpath("//a[contains(text(),'Adjustment')]").click()
    }
    addadjustment(addadjustment)
    {
        cy.get('.justify-content-right > :nth-child(2)').click()
    }
    adjustmentclienttype(adjustmentclienttype)
    {
        cy.xpath("(//div[@class='below']//div)[1]").click()
    }
    adjustmentbusinessclient(adjustmentclienttype)
    {
        cy.xpath("//span[text()='Business']").click()
    }
    adjustmentclient(adjustmentclient)
    {
        cy.get('#walletAccountName').type("TVS infra llc")
    }
    adjustmentclientselect(adjustmentclientselect)
    {
        cy.get('.list-option').click()
    }
    adjustmentaccountnumber(adjustmentaccountnumber)
    {
        cy.xpath("(//div[@class='below'])[2]").click()
    }
    adjustmentaccountnumberselect(adjustmentaccountnumberselect)
    {
        cy.xpath("//span[text()='7110045189']").click()
    }
    adjustmentamount(adjustmentamount)
    {
        cy.get("#amount").type("12")
    }
    adjustmenttype(adjustmenttype)
    {
        cy.xpath("//div[text()=' Adjustment Type ']").click()
    }
    adjustmenttypeselect(adjustmenttypeselect)
    {
        cy.xpath("//span[text()='Manual Credit Adjustment']").click()
    }
    adjustmenttransactionalremarks(adjustmenttransactionalremarks)
    {
        cy.get(':nth-child(2) > :nth-child(3) > div.col-sm-12 > .dama-select-box-forminput').click()
    }
    adjustmenttransactionalremarksselect(adjustmenttransactionalremarksselect)
    {
        cy.get(':nth-child(1) > .deselect-option').click()
    }
    adjustmentremarks(adjustmentremarks)
    {
        cy.get('#remarks1').type("remarks")
    }
    adjustmentinternalremarks(adjustmentinternalremarks)
    {
        cy.get('#internalRemarks').type("internalremarks")
    }
    adjustmentsubmit(adjustmentsubmit)
    {
        cy.get('[type="submit"]').click()
    }
    adjustmentiframe(adjustmentiframe)
    {
        cy.xpath("//button[text()='okay']").click()
    }


}
export default adjustment;